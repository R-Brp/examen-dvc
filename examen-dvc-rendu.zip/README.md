# Examen MLOps - DVC et Pipelines

## Informations personnelles

Nom: Beaurepere
Prenom: Romane
Email: beaurepere.romane@gmail.com

## Lien du depot

GitHub: https://github.com/R-Brp/examen-dvc
DagsHub: https://dagshub.com/R-Brp/examen-dvc
